//TAYLOR SERIES-ROOTED EXPRESSION
#include<iostream>
#include<cmath>
using namespace std;
int main() {
	float num1, taylorSeries = 0.0;
	int h;
	int j=0;
	int t = 1;
	int p;
	int condition;
	float conclusion = 0.0;
	float x = 0.0;
	while (true) {													//get values from user
		cout << "Please enter number  to the rooted expression and h(number of steps)..." << endl;		
		cout << "number: ";
		cin >> num1;
		cout << "h: ";
		cin >> h;
		cout << "entered number: " << num1;
		cout << "\t entered h: " << h << endl<<endl;
		cout << "1) continue\t" << "2) rewrite values"<<endl;
		cin >> condition;
		if (condition == 1) {
			break;
		}
		else if (condition == 2) {                                 //if user entered wrong values:
			system("cls");
			cout << "number: ";
			cin >> num1;
			cout << "h: ";
			cin >> h;
			cout << "entered number: " << num1;
			cout << "\t entered h: " << h << endl << endl;
			cout << "1) continue\t" << "2) rewrite values"<<endl;
			cin >> condition;
			if (condition == 1) {
				break;
			}
			else													//exit the program try 2nd
			{
				cout << "wrong choice";											
				return 0;
			}
		}
		else {														//exit the program
			cout << "wrong choice";
			return 0;
		}
	}        
	system("cls");
	cout << "entered number--> "<<"f("<<num1<<")";
	cout << " entered h: " << h << endl;
	float x0 = num1 - h;											//previous value --> x0
	float numerator = num1 - x0;									//numerator --> (x-x0)
	float x0sqrt = sqrt(x0);										//Square root operation for x0 value
	float derivative1 = (pow(x0, -0.5)) / 2;						//derivative equations for equation
	float derivative2 = (pow(x0, -1.5)) / -4;
	float derivative3 = (pow(x0, -2.5)) * 0.375;
	float derivative4 = (pow(x0, -3.5)) * -9375;
	float derivative5 = (pow(x0, -4.5)) * 6.5625;
	float derivative6 = (pow(x0, -5.5)) * -36.09375;
	float array[7] = { 0,derivative1,derivative2,derivative3,derivative4,derivative5,derivative6 };
	for(int j=1;j<2;j++)
	{
		for (int i = 1; i < 7; i++)
		{
			taylorSeries = ((pow(numerator, i) / (i * t))) * (array[i]);		//taylor series of equation
			conclusion = taylorSeries;
			x = x + taylorSeries;
			t = i * t;						//factorial
			if(i==6)
			cout << "conclusion " << x+ x0sqrt;
		}
	}
	cout << endl; return 0;
}